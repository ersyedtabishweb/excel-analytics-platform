const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true, // email should be unique
  },
  password: {
    type: String,
    required: true,
  },
  role: {
    type: String,
    enum: ['admin', 'user'], // ✅ lowercase values
    default: 'user',         // ✅ default in lowercase
  },
});

module.exports = mongoose.model('User', userSchema);